package peaksoft.dao;

import org.hibernate.*;
import peaksoft.model.User;
import peaksoft.util.Util;

import javax.persistence.TypedQuery;
import java.util.ArrayList;
import java.util.List;

public class UserDaoHibernateImpl implements UserDao {

    public UserDaoHibernateImpl() {

    }

    @Override
    public void createUsersTable() {
        Util.getSession();

    }

    @Override
    public void dropUsersTable() {
        Session session = Util.getSession().openSession();
        session.beginTransaction();
        Query query = session.createQuery("Delete From User");
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();
        System.out.println("Successfully delete all Users");
    }

    @Override
    public void saveUser(String name, String lastName, Byte age) {
            Session session = Util.getSession().openSession();
                session.beginTransaction();
                session.save(new User(name, lastName, age));
                session.getTransaction().commit();
                session.close();
        System.out.println("Успешное создание================================= ");
            }




        /*try {
            User user = new User();
            Session session = Util.getSession().openSession();
            session.beginTransaction();
            session.save(user);
            session.getTransaction().commit();
            session.close();
            System.out.println("Успешное создание================================= " + user);
        } catch (Exception e) {
            System.out.println("Ошибка");
        }*/


    @Override
    public void removeUserById(long id) {
            try {
                Session session = Util.getSession().openSession();
                Transaction transaction = session.beginTransaction();
                session.createSQLQuery("DELETE FROM  users WHERE id = ?").executeUpdate();
                transaction.commit();
                System.out.println(id + " " + "user was remove by id");
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

        /*Session session = Util.getSession().openSession();
        session.beginTransaction();
        User user = (User) session.get(User.class, id);
        session.delete(user);
        session.getTransaction().commit();
        session.close();
        System.out.println("Успешное удаление" + user);

    }*/

    @Override
    public List<User> getAllUsers() {

        List<User> userList;

        Session session = Util.getSession().openSession();
            session.beginTransaction();
            userList = session.createQuery("from User").list();
            session.getTransaction().commit();

        return userList;
    }



            /*System.out.println("Inside getUserList()");

            Session session = Util.getSession().openSession();
            Transaction tx = null;
            List<User> userList = null;

            try {
                tx = session.beginTransaction();
                Criteria criteria = session.createCriteria(User.class);
                userList = criteria.list();
                System.out.println("userList: " + userList);
                tx.commit();
            }catch (HibernateException e) {
                if (tx != null)
                    tx.rollback();
                e.printStackTrace();
            } finally {
                session.close();
            }
            return userList;
        }*/




        /*Session session = Util.getSession().openSession();
        session.beginTransaction();
        List users = session.createQuery("from User ").list();
        session.getTransaction().commit();
        session.close();
        System.out.println("Finded: " + users.size() + " students ");
        return users;*/



    @Override
    public void cleanUsersTable() {
        Session session = Util.getSession().openSession();
        session.beginTransaction();
        Query query = session.createQuery("Delete FROM User");
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();
        System.out.println("Successfully delete all Users");

    }
}
